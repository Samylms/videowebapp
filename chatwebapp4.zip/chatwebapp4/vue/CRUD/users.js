$(function()
{
	$('#addUsers').click(function(event){
		event.preventDefault();
		$.post('process.php?action=addUsers',$('#add-users-form').serialize(),function(resp)
		{
			if (resp['status'] == true)
			{
				$("#success-msg").html(resp['msg']);
				$("#success-msg").show();
				setTimeout(function()
				{ 
				location.href = "index.php";
				 },4000);
			}
			else
			{
				var htm = '<button data-dismiss="alert" class="close" type="button">×</button>';
				$.each(resp['msg'],function(index,val){
					htm += val+" <br>";
					});
				$("#error-msg").html(htm);
				$("#error-msg").show();	
				$(this).prop('disabled',false);
			}
		},'json');
	});
	
	
	
	$('#editUsers').click(function(event){
		event.preventDefault();
		$.post('process.php?action=editUsers',$('#edit-users-form').serialize(),function(resp)
		{
			if (resp['status'] == true)
			{
				$("#success-msg").html(resp['msg']);
				$("#success-msg").show();
				setTimeout(function()
				{ 
				location.href = "index.php";
				 },2000);
			}
			else
			{
				var htm = '<button data-dismiss="alert" class="close" type="button">×</button>';
				$.each(resp['msg'],function(index,val){
					htm += val+" <br>";
					});
				$("#error-msg").html(htm);
				$("#error-msg").show();	
				$(this).prop('disabled',false);
			}
		},'json');
	});
});

function getUsersId(user_id)
{
	var result = confirm("Want to delete record?");
	var user_id = "user_id="+user_id;
    if (result) {
		
		$.post('process.php?action=deleteUsers',user_id,function(resp)
		{
			if (resp['status'] == true)
			{
				$("#row_num_"+user_id).html('');
				$("#success-msg").html(resp['msg']);
				$("#success-msg").show();
			}
			else
			{
				$("#error-msg").html(htm);
				$("#error-msg").show();	
			}
		},'json');
    }	
}