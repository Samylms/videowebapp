<?php
include('../../Model/database_connection.php');

session_start();

if(!isset($_SESSION['user_id']))
{
	header("location:login.php");
}

/**
 * ajouter un user
 */
    $error  = array();
	$res    = array();
	$success = "";
	if(isset($_REQUEST['action']) && $_REQUEST['action'] == "addUsers")
	{
		
		if(empty($_POST['username']))
		{
			$error[] = "User Name field is required";	
		}
		if(empty($_POST['password']))
		{
			$error[] = "Password field is required";	
		}
		if($_POST['password'] != $_POST['cpassword'] )
		{
			$error[] = "Password field and confrim password field is not matched";	
		}
		
	
		 
		if(!preg_match('/^[a-zA-Z0-9]{5,}$/', $_POST['username'])) { 
		   $error[] = "Enter Valid Username";
         } 
		if(count($error)>0)
		{
			$resp['msg']    = $error;
			$resp['status'] = false;	
			echo json_encode($resp);
			exit;
		}
		$pass = md5($_POST['password']);
		  $sqlQuery = "INSERT INTO 	login(password , username, admin)
		  VALUES(:password,:username,:admin)";		   
		  $run = $connect->prepare($sqlQuery);
		  $run->bindParam(':password',$pass, PDO::PARAM_STR); 
          $run->bindParam(':username', $_POST['username'], PDO::PARAM_STR);  
          $run->bindParam(':admin', $_POST['admin'], PDO::PARAM_INT);  
		  $run->execute(); 	
		  
		  $resp['msg']    = "user added successfully";
		  $resp['status'] = true;	
		   echo json_encode($resp);
			exit;	 
		 
		
	}
	/**
 * ediiter un user
 */
	else if(isset($_REQUEST['action']) && $_REQUEST['action'] == "editUsers")
	{
		
	 
		
		  $sqlQuery = "UPDATE login SET username = :username, admin = :admin WHERE user_id = :user_id";
			$run = $connect->prepare($sqlQuery);
      $run->bindParam(':username', $_POST['username'], PDO::PARAM_STR);
 			$run->bindParam(':admin', $_POST['admin'], PDO::PARAM_INT);
			$run->bindParam(':user_id', $_POST['user_id'], PDO::PARAM_INT);
		  $run->execute(); 
		  $resp['msg']    = "User updated successfully";
          $resp['status'] = true;
          print_r($run->errorInfo());	
		  echo json_encode($resp);
		   exit; 	
	}
	/**
 * supprimer un user
 */
	else if(isset($_REQUEST['action']) && $_REQUEST['action'] == "deleteUsers")
	{
		  $sqlQuery = "DELETE FROM login WHERE user_id =  :user_id";
	      $run = $connect->prepare($sqlQuery);
	      $run->bindParam(':user_id', $_POST['user_id'], PDO::PARAM_INT);   
	      $run->execute();
		  $resp['status'] = true;
		  $resp['msg'] = "Record deleted successfully";
		  echo json_encode($resp);
		  
	}
	else if(isset($_REQUEST['action']) && $_REQUEST['action'] == "listUsers")
	{
	    $statement = $connect->prepare("SELECT * from login where user_id > :user_id");
        $statement->execute(array(':user_id' => 0));
		$row = $statement->fetchAll(PDO::FETCH_ASSOC);
	}
?>