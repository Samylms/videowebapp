<?php

include('../../Model/database_connection.php');
session_start();

if(!isset($_SESSION['user_id']))
{
	header("location:../login.php");
}
	   $fetch_users_info = $connect->prepare("SELECT * FROM login WHERE user_id = :user_id");
       $fetch_users_info->execute(array(':user_id' => $_GET['user_id']));
	   $list = $fetch_users_info->fetchAll(PDO::FETCH_ASSOC);
?>
 <!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>edit page </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
    <script src="users.js"></script>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="center">
<form class="form-horizontal" id="edit-users-form" method="post">
          <fieldset>
          
           <div class="controls">
          <input type="hidden" name="user_id" value="<?php echo $list[0]['user_id']; ?>">


          <div class="control-group">											
		 <label for="username" class="control-label">Username</label>
		 <div class="controls">
		 <input type="text" value="<?php echo $list[0]['username']; ?>"   name="username"   class="span6">
		 </div> <!-- /controls -->				
</div> <!-- /control-group -->

 
 

           <div class="control-group">											
		 <label for="admin" class="control-label">Admin</label>
		 <div class="controls">
		 <input  value="<?php echo $list[0]['admin']; ?>" name="admin"   class="span6">
 		 </div> <!-- /controls -->				
        </div> <!-- /control-group -->
 
 
            <br>
            <div class="form-actions">
              <button class="btn btn-primary" type="button" id="editUsers">Save</button>
              <button class="btn">Cancel</button>
            </div>
            <!-- /form-actions -->
          </fieldset>
        </form>
        </div>
        </body>
</html>