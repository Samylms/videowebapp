<?php

include('../../Model/database_connection.php');
session_start();

if(!isset($_SESSION['user_id']))
{
	header("location:login.php");
}
	
?>
 
 <!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>add page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
    <script src="users.js"></script>
    <link rel="stylesheet" href="style.css">

</head>
<body>
<div class="center">

<form class="form-horizontal" id="add-users-form" method="post">
    <fieldset>
            <div class="control-group">
              <label for="username" class="control-label">Username</label>
              <div class="controls">
                <input type="text" placeholder="Username" name="username"   required id="username" class="span6">
                <p class="help-block">Your username is for logging in and cannot be changed.</p>
              </div>
              <!-- /controls --> 
            </div>
           
            <div class="control-group">
              <label for="admin" class="control-label">Admin</label>
              <div class="controls">
                <input type="number"   placeholder="Admin" name="admin"     class="span6">
               </div>
              <!-- /controls --> 
            </div>

            <br>
            <br>
            <div class="control-group">
              <label for="password1" class="control-label">Password</label>
              <div class="controls">
                <input type="password" name="password"  id="password" class="span4">
              </div>
              <!-- /controls --> 
            </div>
            <!-- /control-group -->
            
            <div class="control-group">
              <label for="password2" class="control-label">Confirm</label>
              <div class="controls">
                <input type="password" name="cpassword"  id="cpassword" class="span4">
              </div>
              <!-- /controls --> 
            </div>
            <!-- /control-group --> 
            
            <br>
            <div class="form-actions">
              <button class="btn btn-primary" type="button" id="addUsers">Save</button>
              <button class="btn">Cancel</button>
            </div>
            <!-- /form-actions -->
          </fieldset>
          </div>

        </form>
        </body>
</html>