<?php

include('../../Model/database_connection.php');

session_start();

if(!isset($_SESSION['user_id']))
{
	header("location:../login.php");
}

$statement = $connect->prepare("SELECT * from login where user_id > :user_id");
$statement->execute(array(':user_id' => 0));
$list = $statement->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
    <script src="users.js"></script>
 
</head>
<body>
<a class="btn btn-primary" href="add.php" style="float:right">Ajouter</a>

 <table class="table table-striped table-bordered">
          <thead>
            <tr>
              <th> Username</th>
              <th> Admin</th>
              <th class="td-actions"> Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
				foreach($list as $col)
				{
				  ?>
            <tr id="row_num_<?php echo $col['user_id'];   ?>">
              <td><?php echo $col['username'];  ?></td>
              <td><?php echo $col['admin'];  ?></td>
              <td class="td-actions"><a class="btn btn-small btn-success" href="edit.php?user_id=<?php echo $col['user_id'];   ?>">modifier<i class="icon-large icon-edit"> </i></a><a class="btn btn-danger btn-small" onClick="getUsersId(<?php echo $col['user_id'];   ?>)"   href="javascript:void(0)">supprimer<i class="btn-icon-only icon-remove"> </i></a></td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
        <a class="btn btn-primary" href="../../index.php" style="float:right">Go to app</a>

</body>
</html>
