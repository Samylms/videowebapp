<!--
//login.php
!-->

<?php

include('../Model/database_connection.php');

session_start();

$message = '';

/** $_SESSION pour créé une session */

if(isset($_SESSION['user_id']))
{
	header('location:../index.php');
	

}

if(isset($_POST['login']))
{
	$query = "SELECT * FROM login 
  		WHERE username = :username";
	$statement = $connect->prepare($query);
	$statement->execute(

		array(
			':username' => $_POST["username"]
		) 
	);	
 

/* rowCount() Retourne le nombre de lignes  */
	$count = $statement->rowCount();
	if($count > 0)
	{
		/* fetchAll()  Returns an array containing all of the result set rows  */
		$result = $statement->fetchAll();
		echo $result;
		foreach($result as $row)
		{	
			$_SESSION['admin'] = $row['admin'];

			if($_SESSION['admin'] == 1){
				//debug_to_console( "admin connected" );
 
			/* Verifies that a password matches a hash */
			if(password_verify($_POST["password"], $row["password"]))
			{
				$_SESSION['user_id'] = $row['user_id'];
				$_SESSION['username'] = $row['username'];

				$sub_query = "INSERT INTO login_details 
	     		(user_id) 
	     		VALUES ('".$row['user_id']."')
				";
				$statement = $connect->prepare($sub_query);
				$statement->execute();
				$_SESSION['login_details_id'] = $connect->lastInsertId();
		

				
				header('location:../index.php');
				header('location:CRUD/index.php');

				
				
				} 	
			}

			if ($_SESSION['admin'] == 0) {
 
				
				
			/* Verifies that a password matches a hash */
			if(password_verify($_POST["password"], $row["password"]))
			{
				$_SESSION['user_id'] = $row['user_id'];
				$_SESSION['username'] = $row['username'];

				$sub_query = "INSERT INTO login_details 
	     		(user_id) 
	     		VALUES ('".$row['user_id']."')
				";
				$statement = $connect->prepare($sub_query);
				$statement->execute();
				$_SESSION['login_details_id'] = $connect->lastInsertId();
 
				header('location:../index.php');


				} 	
			}
	
				
		 
			else
			{
				$message = '<label>Wrong Password</label>';
			}
		}
	}
	else
	{
		$message = '<label>Wrong Username</labe>';
	}
}


?>

<html>  
    <head>  
        <title>Chat App</title>  
		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		 

    </head>  
    <body>  

		<!--
			nav menu
		
		<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="#">About</a>
  <a href="#">Services</a>
  <a href="#">Clients</a>
  <a href="#">Contact</a>
</div>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>-->



        <div class="container">
			<br />
			
			<h3 align="center" ><b>Chat App</b></h3><br />
			<br />
			<div class="panel panel-default">
  				<div class="panel-heading">Chat Application Login</div>
				<div class="panel-body">
					<p class="text-danger"><?php echo $message; ?></p>
					<form method="post">
						<div class="form-group">
							<label>Enter Username</label>
							<input type="text" name="username" class="form-control" required />
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input type="password" name="password" class="form-control" required />
						</div>
						<div class="form-group">
							<input type="submit" name="login" class="btn btn-info" value="Login" />
						</div>
						 
						<div align="center">
						<a href="register.php">Mot de passe oublié ?</a>
						</div>
					</form>
 
					<br />
					<br />
 		
				
					 
				</div>
			</div>
		</div>

    </body>  
</html>




 
 