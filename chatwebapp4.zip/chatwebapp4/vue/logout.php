<?php

//logout.php

session_start();

/** destruction de la variable deconnexion  */
session_destroy();

header('location:login.php');

?>